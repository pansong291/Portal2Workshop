[Source MDL Texture Information v1.0]
==========================================================================
(c)2004 Neil "Jed" Jedrzejewski (jed@wunderboy.org) http:///www.wunderboy.org

[Info]
======

This is a quick console app that will tell you the textures used by a MDL
file from a game using the Vavle Source engine. It will list the textures
used by their VMT file plus the folders in which it the model will look
for the textures.

[Installation]
==============

Place MDLTextureInfo.exe in your Source_SDK\Bin folder.


[Instructions and Stuff]
========================

MDLTextureInfo needs to exist in the SourceSDK\Bin folder but doesn't need Steam
to be running to actually work (at the moment).

Create a shortcut to it, or use it via the command line. Either drag and drop
a MDL file onto the shortcut you created or type MDLTextureInfo.exe followed by
the path and filename to your MDL file.

[Known Bugs]
============

* Will crap out if you drop a non MDL file onto it (if you do that, your either
  plain stupid or an eternal optimist).

[Changes]
=========

1.0	Initial Release

License/Disclaimer
==================
This software is experimental. I, Neil Jedrzejewski, assume no responsibility
whatsoever for its use by other parties, and makes no guarantees, expressed or
implied, about its quality, reliability, or any other characteristic.